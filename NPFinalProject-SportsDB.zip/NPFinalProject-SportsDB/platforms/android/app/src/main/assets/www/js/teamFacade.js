function addTeam() {
    if(validateAddTeam()) {
        var name = $("#teamName").val();
        var abbreviation = $("#teamAbbr").val();
        var city = $("#teamCity").val();
        var arena = $("#arenaName").val();
        var capacity = $("#stadiumCapacity").val();
        var sport = $("#sportSelect").val();
        var founded = $("#teamFounded").val();
        var owner = $("#teamOwner").val();
        var manager = $("#teamManager").val();
        var option = [sport,name, abbreviation, city, arena, capacity, founded, owner, manager];

        function callback() {
            alert("Team added successfully");
            $.mobile.changePage("#pageTeams", {transition: 'none'});

        }

        Team.insert(option, callback);
    }
}
function showAllTeams() {
    var option = [];

    function callback(tx, results) {

        var htmlcode = "";
        var sport="";
        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);

            if(row['sportId']==1){sport = 'Hockey';}
            if(row['sportId']==2){sport = 'Basketball';}
            if(row['sportId']==3){sport = 'Soccer';}
            if(row['sportId']==4){sport = 'Baseball';}
            if(row['sportId']==5){sport = 'Football';}
            htmlcode += "<li><a data-role='button' data-row-id=" + row['id'] +
                " href='#'>" + "<h1>Team: " + row['name'] + "</h1>" +
                "<p>Sport: " + sport+ "</p>" +
                "<p>Abbreviation: " + row['abbreviation'] + "</p>" +
                "<p>City: " + row['city'] + "</p>" +
                "</a></li>"
        }
        if (htmlcode=="") {
            htmlcode="<h3 align='center'>N/A <br>No Teams Created</h3>";
        }
        var lv = $("#lvAll");
        lv = lv.html(htmlcode);
        lv.listview("refresh");
        $("#lvAll a").on("click", clickHandler);

        function clickHandler() {
            localStorage.setItem("id", $(this).attr("data-row-id"));
            // navigate to a page by code
            $.mobile.changePage("#pageDetail", {transition: 'none'});
            // $(location).prop('href', '#pageDetail'); // also works
        }
    }

    Team.selectAll(option, callback);

}
function showATeam() {
    Sport.selectAll(typeTable);
    function typeTable(tx, options) {
        let htmlCode="";
        for (var i = 0; i < options.rows.length; i++) {
            htmlCode += "<option value = '" + options.rows[i]['id'] + "'>" + options.rows[i]['name'] + "</option>";
            // alert(htmlCode);
        }
        $("#editsportSelect").html(htmlCode);
        $('#editsportSelect').selectmenu("refresh");

    }
    //var id = $("#txtId").val();
    var id= localStorage.getItem("id");
    var option = [id];

    function callback(tx, results) {
        var row = results.rows.item(0);

        $("#editteamName").val(row['name']);
        $("#editteamAbbr").val(row['abbreviation']);
        $("#editteamCity").val(row['city']);
        $("#editsportSelect").val(row['sportId']);
       // alert($("#editsportSelect").val());
        //alert(row['sport']);
        $('#editsportSelect').selectmenu("refresh");
        $("#editarenaName").val(row['arena']);
        $("#editstadiumCapacity").val(row['capacity']);
        $("#editteamFounded").val(row['founded']);
        $("#editteamOwner").val(row['owner']);
        $("#editteamManager").val(row['manager']);

        // $("#editTeamForm :select").selectlistradio("refresh");
    }


    Team.select(option, callback);
}
function deleteATeam() {
    // var id = $("#txtId").val();
    var id= localStorage.getItem("id");
    var option = [id];
    function callback(){
        alert("Team deleted successfully");

    }
    Team.delete(option, callback);
    $(location).prop('href', '#pageTeams');
}
function updateTeam() {
    if(validateEditTeam()) {
        var id= localStorage.getItem("id");

        var name = $("#editteamName").val();
        var abbreviation = $("#editteamAbbr").val();
        var city = $("#editteamCity").val();
        var arena = $("#editarenaName").val();
        var capacity = $("#editstadiumCapacity").val();
        var sport = $("#editsportSelect").val();
        var founded = $("#editteamFounded").val();
        var owner = $("#editteamOwner").val();
        var manager = $("#editteamManager").val();
// alert(id);
        var option = [sport, name, abbreviation, city, arena, capacity, founded, owner, manager,id];
    }
    function callback(){
        alert("Team updated successfully");
        $.mobile.changePage("#pageTeams", {transition: 'none'});

    }

    Team.update(option, callback);
}
function clearDatabase() {
    var result = confirm("Are you sure you want to clear the database?");
    try {
        if (result) {
            DB.dropTables();
            // alert("Database cleared");
        }
    } catch (e) {
        alert(e);
    }
}
function updateDropdown() {
    // alert("update2");
        Sport.selectAll(typeTable);
        function typeTable(tx, options) {
            let htmlCode="";
            for (var i = 0; i < options.rows.length; i++) {
                htmlCode += "<option value = '" + options.rows[i]['id'] + "'>" + options.rows[i]['name'] + "</option>";

            }
                $("#sportSelect").html(htmlCode);
                $('#sportSelect').selectmenu("refresh");

        }
}
