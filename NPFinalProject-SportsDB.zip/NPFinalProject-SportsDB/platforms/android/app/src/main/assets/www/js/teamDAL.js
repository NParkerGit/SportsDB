var Team = {
    insert: function (option, callback) {
        function txFunction(tx){
            var sql = "INSERT INTO team(sportId,name,abbreviation,city,arena,capacity,founded,owner,manager) values(?,?,?,?,?,?,?,?,?);";

            tx.executeSql(sql, option, callback, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    selectAll: function (option, callback) {
        function txFunction(tx){
            var sql = "SELECT * FROM team;";

            tx.executeSql(sql, option, callback, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    select: function (option, callback) {
        function txFunction(tx){
            var sql = "SELECT * FROM team WHERE id=?;";

            tx.executeSql(sql, option, callback, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    update: function (option, callback) {
        function txFunction(tx){
            var sql = "UPDATE team " +
                "SET sportId=?, name=?, abbreviation=?, city=?, " +
                "arena=?, capacity=?, founded=?, owner=?, " +
                "manager=?" +
                "WHERE id=?;";


            tx.executeSql(sql, option, callback, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    delete: function (option, callback) {
        function txFunction(tx){
            var sql = "DELETE FROM team WHERE id=?;";

            tx.executeSql(sql, option, callback, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};
var Sport = {
    selectAll: function (typeTable) {
        function txFunction(tx){
            var sql = "SELECT * FROM sport;";

            tx.executeSql(sql, [], typeTable, errorHandler );
        }
        function successTransaction(){
            console.info("Success: transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};
