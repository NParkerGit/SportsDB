
var db;

function errorHandler(tx, error) {
    console.error("SQL error: " + tx + " ( " + error.code + " ) -- " + error.message);
}

var DB = {
    createDatabase: function () {
        var shortName = "SportsDB";
        var version  = "1.0";
        var displayName = "DB for Sports DB";
        var dbSize = 2 * 1024 * 1024;

        function dbCreateSuccess(){
            console.info("Success: Database created successfully");
        }
        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);
    },
    createTables: function () {
        function txFunction(tx){
            var options = [];
            var sql = "DROP TABLE sport;";
            tx.executeSql(sql, options, successCallback, errorHandler);
            sql = "CREATE TABLE IF NOT EXISTS sport( "
                + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "name VARCHAR(20) NOT NULL);";

            tx.executeSql(sql, options, successCallback, errorHandler);
            sql = ["INSERT INTO sport(name) VALUES('Hockey');",
                "INSERT INTO sport(name) VALUES('Basketball');",
                "INSERT INTO sport(name) VALUES('Soccer');",
                "INSERT INTO sport(name) VALUES('Baseball');",
                "INSERT INTO sport(name) VALUES('Football');"];
            for (var i = 0; i < sql.length; i++) {
                tx.executeSql(sql[i], options, successCallback, errorHandler);
            }

                sql = "CREATE TABLE IF NOT EXISTS team( " +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "sportId INTEGER NOT NULL," +
                "name VARCHAR(30) NOT NULL," +
                "abbreviation VARCHAR(5)," +
                "city VARCHAR(30)," +
                "arena VARCHAR(30)," +
                "capacity INTEGER," +
                "founded DATE," +
                "owner VARCHAR(30)," +
                "manager VARCHAR(30)," +
                "FOREIGN KEY(sportId) REFERENCES sport(id));";

            tx.executeSql(sql, options, successCallback, errorHandler);

            function successCallback(){
                console.info("Success: Table created successfully");
            }
        }

        function successTransaction(){
            console.info("Success: Transaction Successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    dropTables: function () {
        function txFunction(tx){
            var options = [];
            var sqlSport = "DROP TABLE IF EXISTS sport;";
            var sqlTeam = "DROP TABLE IF EXISTS team";

            function successCallback(){
                console.info("Success: Tables dropped successfully");

            }

            tx.executeSql(sqlSport, options, successCallback, errorHandler);
            tx.executeSql(sqlTeam, options, successCallback, errorHandler);

        }

        function successTransaction(){
            console.info("Success: Transaction Successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};
