var lat;
var lng;
var alt;

function showMap() {
    var platform= new H.service.Platform({
        'apikey':'vLB_UdbZIo8y4j2qYUKWpsYvplQ52uOni1hca_xZrq0'
    });
    var maptypes = platform.createDefaultLayers();
    var map = new H.Map(
        document.getElementById('mapContainer'),
        maptypes.vector.normal.map,
        {
            zoom: 16,
            // zoom: 15,
            center: {
                lng:lng,
            lat:lat
            }
        }
    );
    var icon=new H.map.Icon('../pin.PNG');

    var marker = new H.map.Marker(
        {
        lat:lat,
        lng:lng
        },
        {
          icon:icon
        }
        );

    map.addObject(marker);
}

function getPosition()
{

    console.info("getPosition () successfully called");

    try{
        if (navigator.geolocation !=null)
        {
            var options={
                enableHighAccuracy: true,
                timeout: 60000,
                maximumAge: 0
            }
            function successCallback(position){
                var coordinates = position.coords;

                lat=43.4789704;
                // lat=coordinates.latitude+0.004782;
                // lng=coordinates.longitude-0.0067912;
                lng=-80.520448;
                alt=coordinates.altitude;

                console.info("Latitude: "+lat+"\nLongitude: "+lng+"\nltitude: "+alt)

                showMap();


            }
            function errorCallback(error){
                var msg="";

                try{
                    if(error){
                        switch (error.code) {
                            case error.TIMEOUT:
                                msg="TIMEOUT: "+ error.message;
                                break;
                            case error.PERMISSION_DENIED:
                                msg="PERMISSION DENIED: "+ error.message;
                                break;
                            case error.POSITION_UNAVAILABLE:
                                msg="POSITION UNAVAILABLE: "+ error.message;
                                break;
                            default:
                                msg="UNKNOWN EXCEPTION (:"+error.code+"): "+ error.message;
                                break;
                        }
                        console.info(msg);

                    }
                }
               catch (e) {
                   console.error("Exception in errorCallback(): "+e);
               }

            }
            navigator.geolocation.getCurrentPosition(successCallback,errorCallback,options);
        }
        else{
            console.error("Geolocation not supported");
        }
    }
    catch (e) {
        console.error("Exception in getPosition(): "+e);
    }


}
