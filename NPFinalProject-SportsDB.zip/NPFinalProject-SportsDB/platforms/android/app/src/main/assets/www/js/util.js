function validateAddTeam() {
    var form = $("#addTeamForm");
    form.validate({
        rules:{
            teamName:{
                required:true,
            },
            teamAbbr:{
                required:true,
                minlength:3
            },
            teamCity:{
                required:true,
            },
            teamFounded:{
                founded:true,
            },
            stadiumCapacity:{
                range:[15000,100000]
            }
        },
        messages:{
            teamName:{
                required:'You must enter a Team Name',
            },
            teamAbbr:{
                required:'You must enter a Team Abbreviation',
                minlength: 'Abbreviation must be 3 or More Characters'
            },
            teamCity:{
                required:'You must enter a Team City',
            },
            teamFounded:{
                founded:'Team must be founded in the past',
            },
            stadiumCapacity:{
                range:'You must have a capacity between 15000 and 100000'
            }
        }
    });
    return form.valid();
}
function validateEditTeam() {
    var form = $("#editTeamForm");
    form.validate({
        rules:{
            editteamName:{
                required:true,
            },
            editteamAbbr:{
                required:true,
                minlength:3
            },
            editteamCity:{
                required:true,
            },
            teamFounded:{
                founded:true,
            },
            editstadiumCapacity:{
                range:[15000,100000]
            }
        },
        messages:{
            editteamName:{
                required:'You must enter a Team Name',
            },
            editteamAbbr:{
                required:'You must enter a Team Abbreviation',
                minlength: 'Abbreviation must be 3 or More Characters'
            },
            editteamCity:{
                required:'You must enter a Team City',
            },
            editteamFounded:{
                founded:'Team must be founded in the past',
            },
            editstadiumCapacity:{
                range:'You must have a capacity between 15000 and 100000'
            }
        }
    });
    return form.valid();
}
function validateUser() {
    var form = $("#validUser");
    form.validate({
        rules:{
            email:{
                required:true,
                emailCheck:true
            },
            password:{
                required:true,
            },
            verifyPassword:{
                required:true,
                equalTo: "#password"
            }
        },
        messages:{
            email:{
                required:'You must enter an email',
                emailCheck:'You must enter a valid email',
            },
            password:{
                required:'You must enter a Password',
            },
            verifyPassword:{
                required:'You must enter Password again',
                equalTo:'Password does not match',
            }
        }
    });
    return form.valid();
}
jQuery.validator.addMethod("founded",
    function(value, element){
        var date = value;
        var today = new Date();
        date = new Date(date);

        if(date > today){
            return false;
        }
        else{
            return true;
        }
    },
    "date check");


jQuery.validator.addMethod("emailCheck",
    function (value,element) {
        var emailReg = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;

        return emailReg.test(value);
    },
    "Custom Email Checker");
