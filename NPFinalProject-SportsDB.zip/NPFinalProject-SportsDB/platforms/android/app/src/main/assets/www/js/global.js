function btnAdd_click() {
    addTeam();
}function pageAdd_Show() {
    updateDropdown();
}
function btnUpdate_click() {
    updateTeam();
}
function btnCancel_click() {
    $.mobile.changePage("#pageTeams", {transition: 'none'});
}

function btnValidate_click() {
    validateUser();
    if (validateUser()) {
        $("#clearDB").show();
        $("#validUser").hide();
    }
    else {
        $("#clearDB").hide();
    }

}

function btnDelete_click() {
    deleteATeam();
}

function pageTeams_show() {
    showAllTeams();
}

function pageDetail_show() {
    showATeam();
}

function btnClearDatabase_click() {
    clearDatabase();
}
function init() {
    console.info("DOM is ready");

    $("#btnAdd").on("click", btnAdd_click);
    $("#pageAdd").on("pageshow", pageAdd_Show);


    $("#btnShow").on("click", pos);
    $("#btnDelete").on("click", btnDelete_click);
    $("#btnUpdate").on("click", btnUpdate_click);
    $("#btnCancel").on("click", btnCancel_click);
    $("#pageTeams").on("pageshow", pageTeams_show);
    $("#pageDetail").on("pageshow", pageDetail_show);
    $("#btnValidate").on("click", btnValidate_click);
    $("#btnClearDatabase").on("click", btnClearDatabase_click);
    $("#Location").on("click", pos);

}
function pos() {
getPosition();
}
function  initDB(){
    console.info("Creating database...");
    try {
        DB.createDatabase();
        if (db) {
            console.info("Creating tables...");
            DB.createTables();
        }
        else{
            console.error("Error: cannot create tables: Database not available");
        }

    } catch (e) {
        console.error("Error: (Fatal) error in initDB(). Can not proceed");
    }


}

$(document).ready(function () {
    init();
    initDB();
});
